package com.mashibing.tank;

public enum Dir {
	LEFT, UP, RIGHT, DOWN
}
